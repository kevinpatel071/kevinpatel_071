<?php
$conn=mysqli_connect("localhost","root","","onlne_notice");
?>

	